bl_info = {
    "name": "Adjust Keyframes for Rotated Armature",
    "blender": (2, 80, 0),
    "category": "Animation",
}

import bpy
import math
import mathutils

class RotateArmatureFixOperator(bpy.types.Operator):
    """Adjust Keyframes for Rotated Armature"""
    bl_idname = "object.rotate_armature_fix"
    bl_label = "Adjust Keyframes"
    bl_options = {'REGISTER', 'UNDO'}

    rotation_angle: bpy.props.FloatProperty(
        name="Rotation Angle",
        description="Rotation angle in degrees",
        default 90.0,
    )

    rotation_axis: bpy.props.EnumProperty(
        name="Rotation Axis",
        description="Axis to apply rotation",
        items=[
            ('X', "X", "Rotate around X axis"),
            ('Y', "Y", "Rotate around Y axis"),
            ('Z', "Z", "Rotate around Z axis"),
        ],
        default='Z',
    )

    def execute(self, context):
        angle_radians = math.radians(-self.rotation_angle)
        rotation_matrix = mathutils.Matrix.Rotation(angle_radians, 4, self.rotation_axis)

        # Select the active object
        armature = bpy.context.view_layer.objects.active

        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "Active object is not an armature")
            return {'CANCELLED'}

        # Get the action associated with the armature
        action = armature.animation_data.action

        if not action:
            self.report({'ERROR'}, "No animation data found")
            return {'CANCELLED'}

        # Loop through all the fcurves and keyframes in the action
        for fcurve in action.fcurves:
            for keyframe in fcurve.keyframe_points:
                frame = keyframe.co[0]
                bpy.context.scene.frame_set(int(frame))
                data_path = fcurve.data_path
                if not data_path.startswith("pose.bones"):
                    continue
                bone_name = data_path.split('"')[1]
                transform_type = data_path.split('.')[-1]
                pose_bone = armature.pose.bones.get(bone_name)

                if not pose_bone:
                    continue

                if transform_type == 'location':
                    pose_bone.location = rotation_matrix @ pose_bone.location
                elif transform_type == 'rotation_quaternion':
                    rot_matrix = pose_bone.rotation_quaternion.to_matrix().to_4x4()
                    new_rot_matrix = rotation_matrix @ rot_matrix
                    pose_bone.rotation_quaternion = new_rot_matrix.to_quaternion()
                elif transform_type == 'rotation_euler':
                    pose_bone.rotation_euler.rotate(rotation_matrix)
                elif transform_type == 'scale':
                    pose_bone.scale = rotation_matrix.to_scale()

        bpy.context.view_layer.update()
        return {'FINISHED'}

class RotateArmatureFixPanel(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Adjust Keyframes for Rotated Armature"
    bl_idname = "OBJECT_PT_rotate_armature_fix"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Animation'

    def draw(self, context):
        layout = self.layout
        layout.operator(RotateArmatureFixOperator.bl_idname)

def register():
    bpy.utils.register_class(RotateArmatureFixOperator)
    bpy.utils.register_class(RotateArmatureFixPanel)

def unregister():
    bpy.utils.unregister_class(RotateArmatureFixOperator)
    bpy.utils.unregister_class(RotateArmatureFixPanel)

if __name__ == "__main__":
    register()

