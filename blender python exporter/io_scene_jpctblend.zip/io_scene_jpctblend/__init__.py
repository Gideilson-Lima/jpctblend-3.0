# Copyright (c) 2014 Andres Jessé Porfirio. www.andresjesse.com
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy of
# this software and associated documentation files (the "Software"), to deal in
# the Software without restriction, including without limitation the rights to
# use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
# the Software, and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
# FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
# COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
# IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
if "bpy" in locals():
    from . import export_jpctblend

bl_info = {
    "name": "JPCTBlend Scene",
    "author": "Andres Jessé Porfirio; Gideilson Lima Carvalho",
    "blender": (2, 80, 0),
    "location": "File > Import-Export",
    "description": "Export JPCTBlend Scene",
    "warning": "",
    "wiki_url": "https://github.com/andresjesse/jpctblend/wiki",
    "tracker_url": "",
    "support": 'OFFICIAL',
    "category": "Import-Export"}

import os
import bpy
from bpy.app.handlers import persistent

from bpy.props import (CollectionProperty,
                       StringProperty,
                       BoolProperty,
                       EnumProperty,
                       FloatProperty,
                       )
from bpy_extras.io_utils import (ImportHelper,
                                 ExportHelper,
                                 axis_conversion,
                                 )
def create_group():
# Check if the group already exists to avoid duplication
    if 'TextureSplat' in bpy.data.node_groups:
        return
    posX = -350
    posY = 0
    st = -170
    mGroup = bpy.data.node_groups.new('TextureSplat','ShaderNodeTree')
    group_inputs = mGroup.nodes.new('NodeGroupInput')
    group_inputs.location = (posX,0)
    posX-=st
    group_outputs = mGroup.nodes.new('NodeGroupOutput')
    mGroup.inputs.new('NodeSocketColor','Map')
    mGroup.inputs.new('NodeSocketColor','R channel')
    mGroup.inputs.new('NodeSocketColor','G channel')
    mGroup.inputs.new('NodeSocketColor','B channel')
    mGroup.outputs.new('NodeSocketColor','f_image')
    node_sep = mGroup.nodes.new('ShaderNodeSeparateRGB')
    node_sep.location = (posX,posY)
    posX-=st
    node_mix1 = mGroup.nodes.new('ShaderNodeMixRGB')
    node_mix1.blend_type='ADD'
    node_mix1.inputs['Color1'].default_value = (0,0,0,1)
    node_mix1.location= (posX,posY)
    posY+=st
    node_mix2 = mGroup.nodes.new('ShaderNodeMixRGB')
    node_mix2.location =(posX,posY)
    node_mix2.blend_type='ADD'
    node_mix2.inputs['Color1'].default_value = (0,0,0,1)
    posY+=st
    node_mix3 = mGroup.nodes.new('ShaderNodeMixRGB')
    node_mix3.location = (posX,posY)
    node_mix3.blend_type='ADD'
    node_mix3.inputs['Color1'].default_value = (0,0,0,1)
    posY+=st
    posX-=st
    posY = 0
    node_mix4 = mGroup.nodes.new('ShaderNodeMixRGB')
    node_mix4.location = (posX,posY)
    node_mix4.blend_type='ADD'
    node_mix4.inputs['Color1'].default_value = (0,0,0,1)
    posY+=st
    posX-=st
    node_mix5 = mGroup.nodes.new('ShaderNodeMixRGB')
    node_mix5.location = (posX,posY)
    node_mix5.blend_type='ADD'
    node_mix5.inputs['Color1'].default_value = (0,0,0,1)
    posY+=st
    posX-=st
    mGroup.links.new(group_inputs.outputs['Map'],node_sep.inputs['Image'])
    mGroup.links.new(group_inputs.outputs['R channel'],node_mix1.inputs['Color2'])
    mGroup.links.new(node_sep.outputs['R'],node_mix1.inputs['Fac'])
    mGroup.links.new(group_inputs.outputs['G channel'],node_mix2.inputs['Color2'])
    mGroup.links.new(node_sep.outputs['G'],node_mix2.inputs['Fac'])
    mGroup.links.new(group_inputs.outputs['B channel'],node_mix3.inputs['Color2'])
    mGroup.links.new(node_sep.outputs['B'],node_mix3.inputs['Fac'])
    mGroup.links.new(node_mix1.outputs['Color'], node_mix4.inputs['Color1'])
    mGroup.links.new(node_mix2.outputs['Color'],node_mix4.inputs['Color2'])
    mGroup.links.new(node_mix4.outputs['Color'], node_mix5.inputs['Color1'])
    mGroup.links.new(node_mix3.outputs['Color'], node_mix5.inputs['Color2'])
    mGroup.links.new(node_mix5.outputs['Color'],group_outputs.inputs['f_image'])    
    group_outputs.location = (posX,0)
    
class ExportJPCTBlend(bpy.types.Operator, ExportHelper):
    """Export a Blender Scene to be used in JPCT Engine (JPCTBlend system), """ 
    bl_idname = "export_scene_jpctblend.xml"
    bl_label = "Export JPCTBlend"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    
    filename_ext = ""
    filter_glob = StringProperty(default="*.xml", options={'HIDDEN'})

    filepath = bpy.props.StringProperty(
        name="File Path", 
        description="File path used for exporting the JPCTBlend Scene", 
        maxlen= 1024, default= "")
    
    def execute(self, context):
        print("Load", self.properties.filepath)
        print(self.properties.filepath)
        from . import export_jpctblend
        export_jpctblend.JPCTSceneExporter(self.properties.filepath)
        return {'FINISHED'}
 
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

#	
#    Registration
#
@persistent
def load_handler(dummy):
	create_group()
	
def menu_func_export(self, context):
    self.layout.operator(ExportJPCTBlend.bl_idname, text="JPCTBlend Scene (.xml)")
 
def register():
    bpy.utils.register_class(ExportJPCTBlend)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    bpy.app.handlers.load_post.append(load_handler)
def unregister():
    bpy.utils.unregister_class(ExportJPCTBlend)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
 
if __name__ == "__main__":
    register()
